const path = require("path");
const webpack = require("webpack");
const HtmlWebpackPlugin = require("html-webpack-plugin");

module.exports = {
  context: path.join(__dirname, "src"),
  mode: "development",
  devtool: "source-map",

  entry: {
    shop: "./shop"
  },

  module: {
    rules: [
      {
        test: /\.css$/,
        use: ["style-loader", "css-loader"]
      }
    ]
  },

  plugins: [
    new HtmlWebpackPlugin({
      title: "Test",
      hash: true,
      template: "./index.html"
    }),

    new webpack.HotModuleReplacementPlugin()
  ],

  devServer: {
    hot: true
  }
};
