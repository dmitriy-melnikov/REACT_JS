import * as state from "./state";
import "./home.css";

export function action() {
  console.log("Application action");
  state.action();
}

let demoComponent = state.component();

document.body.appendChild(demoComponent);

// HMR interface
if (module.hot) {
  // Capture hot update
  module.hot.accept("./state.js", () => {
    const nextComponent = state.component();

    // Replace old content with the hot loaded one
    document.body.replaceChild(nextComponent, demoComponent);

    demoComponent = nextComponent;
  });
}
