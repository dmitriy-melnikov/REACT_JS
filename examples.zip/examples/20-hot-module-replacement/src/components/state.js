export function action() {
  console.log("State action");
}

export const component = function() {
  const root = document.createElement("div");
  root.innerHTML = "Hello";
  return root;
};
