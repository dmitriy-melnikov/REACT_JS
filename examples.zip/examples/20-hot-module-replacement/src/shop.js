import * as app from "./components/application";
import * as item from "./components/item";

function run() {
  app.action();

  console.log("You are on the Shop Page");

  item.action();
}

setInterval(run, 3000);

if (module.hot) {
  module.hot.accept("./components/application", function() {});
}
