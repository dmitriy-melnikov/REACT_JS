const path = require("path");
const webpack = require("webpack");

module.exports = {
  mode: 'development',
  devtool: 'none',

  plugins: [
    new webpack.DefinePlugin({
      VERSION: JSON.stringify("5fa3b9"),
      BROWSER_SUPPORTS_HTML5: true
    })
  ]
};
