console.log("Running App version " + VERSION);

if (BROWSER_SUPPORTS_HTML5) {
    console.log("Browser is GOOD");
}