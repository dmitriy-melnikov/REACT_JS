import './home.css';
import './menu.css';
import './one.css';

console.log('init');