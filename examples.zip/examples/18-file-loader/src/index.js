import logo from './images/logo.png';

console.log(logo);