const path = require("path");

module.exports = {
  mode: "development",

  devtool: "source-map",

  module: {
    rules: [
      {
        test: /\.(ttf|eot|svg|woff|png)$/,
        loader: "file-loader",
        options: {
          name: "[path][name].[ext]?[hash]"
        }
      }
    ]
  }
};
