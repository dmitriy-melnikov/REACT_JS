const result =_.intersection([2, 1], [2, 3]);
console.log(result);  // => [2]
