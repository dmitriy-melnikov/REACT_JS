const path = require("path");
const webpack = require("webpack");

module.exports = {
  mode: "development",
  devtool: "none",

  plugins: [
    new webpack.ProvidePlugin({
      _: "lodash"
    })
  ]
};
