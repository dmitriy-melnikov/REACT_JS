import './c';
console.log('a');