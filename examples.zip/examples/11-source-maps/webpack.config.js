const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");

module.exports = {
  context: path.resolve(__dirname, "src"),

  entry: {
    a: "./a",
    b: "./b"
  },

  mode: "development",

  devtool: "eval",
  //devtool: "source-map",

  plugins: [
    new HtmlWebpackPlugin({
      title: "Example"
    })
  ]
};
