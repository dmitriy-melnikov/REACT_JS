const path = require("path");

module.exports = {
  context: path.join(__dirname, "src"),
  devtool: "none",
  mode: "development",

  entry: {
    home: "./Home",
    order: "./Order",
    profile: "./Profile",
    shop: "./Shop"
  },

  optimization: {
    splitChunks: {
      cacheGroups: {
        commons: {
          name: "commons",
          chunks: "all",
          minSize: 0,
          minChunks: 2
        }
      }
    }
  }
};
