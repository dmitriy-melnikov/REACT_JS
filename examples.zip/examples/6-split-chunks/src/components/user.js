export function action() {
    console.log('User action');
}