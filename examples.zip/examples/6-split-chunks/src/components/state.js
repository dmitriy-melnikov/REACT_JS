import * as user from './user';

export function action() {
    user.action();
    console.log('State action');
}