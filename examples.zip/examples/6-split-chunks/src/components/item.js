import * as user from './user';

export function action() {
    console.log('Item action');
}