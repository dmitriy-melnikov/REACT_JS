import * as app from './components/application';

Application.action();

console.log('You are on the Home Page');