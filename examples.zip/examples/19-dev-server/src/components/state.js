export function action() {
    console.log('State action');
}

import('./user').then(console.log);