const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");

module.exports = {
  context: path.join(__dirname, "src"),

  entry: "./index.tsx",

  mode: "development",

  devtool: "source-map",

  resolve: {
    extensions: [".ts", ".tsx", ".js"]
  },

  module: {
    rules: [
      {
        test: /\.tsx?$/,
        loader: "awesome-typescript-loader",
        exclude: /node_modules/,
        options: {
          useCache: true
        }
      }
    ]
  },

  plugins: [
    new HtmlWebpackPlugin({
      title: "Example",
      hash: true,
      template: path.resolve(__dirname, "./index.html")
    })
  ]
};
