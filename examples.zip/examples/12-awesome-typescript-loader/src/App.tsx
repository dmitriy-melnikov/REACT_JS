import * as React from "react";
import { Hello } from "./Hello";

export class App extends React.PureComponent {
  public render() {
    return (
      <main>
        <Hello greeting="Hi" />
      </main>
    );
  }
}
