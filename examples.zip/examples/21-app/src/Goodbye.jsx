import * as React from "react";

export class Goodbye extends React.PureComponent {
  render() {
    return <h2>Goodbye</h2>;
  }
}
