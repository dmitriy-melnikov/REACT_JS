const path = require("path");

module.exports = {
  context: path.join(__dirname, "src"),

  mode: "development",

  devtool: "source-map",

  entry: {
    main: ["lodash", "./a"]
  },

  module: {
    rules: [
      {
        test: require.resolve("lodash"),
        loader: "expose-loader?lodash"
      }
    ]
  },

  resolve: {
    extensions: [".js"]
  }
};
