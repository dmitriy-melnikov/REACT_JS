import * as app from './components/application';
import * as customer from './components/customer';

app.action();

console.log('You are on the Profile Page');

customer.action();