import * as app from './components/application';
import * as cart from './components/cart';

app.action();

console.log('You are on the Order Page');

cart.action();