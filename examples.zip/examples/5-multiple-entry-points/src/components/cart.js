import * as item from './item';

export function action() {
    item.action();
    console.log('Cart action');
}