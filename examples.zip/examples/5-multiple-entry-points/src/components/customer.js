export function action() {
    console.log('Customer action');
}