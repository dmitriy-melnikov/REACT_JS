const path = require("path");

module.exports = {
  context: path.join(__dirname, "src"),
  mode: "development",
  devtool: 'none',

  entry: {
    home: "./home",
    order: "./order",
    profile: "./profile",
    shop: "./shop"
  }
};
