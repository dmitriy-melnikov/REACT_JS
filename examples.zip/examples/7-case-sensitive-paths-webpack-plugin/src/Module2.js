import './Mod5';
console.log('module2')