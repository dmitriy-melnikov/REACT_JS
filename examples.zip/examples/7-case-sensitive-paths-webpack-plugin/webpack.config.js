const path = require("path");
const CaseSensitivePathsPlugin = require("case-sensitive-paths-webpack-plugin");

module.exports = {
  mode: "development",
  devtool: 'none',

  plugins: [new CaseSensitivePathsPlugin()]
};
