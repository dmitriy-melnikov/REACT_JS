import b from './b';
console.log(b);