const path = require("path");

module.exports = {
  context: path.join(__dirname, "src"),

  mode: "development",

  devtool: "source-map",

  entry: {
    main: "./a"
  },

  module: {
    rules: [
      {
        test: /b.js/,
        loader: "exports-loader?hiddenVar"
      }
    ]
  }
};
