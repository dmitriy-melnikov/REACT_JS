import * as app from './components/application';
import * as item from './components/item';

app.action();

console.log('You are on the Shop Page');

item.action();