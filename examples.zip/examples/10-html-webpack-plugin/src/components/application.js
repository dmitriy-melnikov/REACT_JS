import * as state from './state';

export function action() {
    console.log('Application action');
    state.action();
}