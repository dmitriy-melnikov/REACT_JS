export function action() {
    console.log('State action');
}