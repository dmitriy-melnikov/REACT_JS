const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");

module.exports = {
  context: path.resolve(__dirname, "src"),

  mode: "development",

  devtool: "none",

  entry: {
    shop: "./Shop",
    another: "./Another.js"
  },

  plugins: [
    new HtmlWebpackPlugin({
      title: "Example",
      hash: true,
      template: "./index.html"
    })
  ]
};
