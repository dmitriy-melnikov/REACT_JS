import './home.less';
import './menu.less';

console.log('init');